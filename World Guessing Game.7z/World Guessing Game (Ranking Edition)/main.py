from jogo_app import JogoApp

if __name__ == "__main__":
    app = JogoApp()
    app.mainloop()
